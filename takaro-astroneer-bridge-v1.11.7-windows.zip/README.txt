Takaro Astroneer Bridge - v1.11.7
==================================

INSTALLATION INSTRUCTIONS
-------------------------

Step 1: Install Node.js
-----------------------
You MUST have Node.js installed before running this bridge.

Easy way (PowerShell as Administrator):
  winget install OpenJS.NodeJS.LTS

Or download from: https://nodejs.org/

RESTART YOUR COMPUTER after installing Node.js!


Step 2: Install Dependencies
-----------------------------
Open PowerShell or Command Prompt in this folder and run:

  npm install

This will download all required packages (may take a few minutes).


Step 3: Enable RCON on Astroneer Server
----------------------------------------
Edit this file on your Astroneer server:
  \astroneer\Astro\Saved\Config\WindowsServer\AstroServerSettings.ini

Add these lines:
  ConsolePort=5000
  ConsolePassword=your-password-here

Save and RESTART your Astroneer server.


Step 4: Configure the Bridge
-----------------------------
Open TakaroConfig.txt in Notepad and edit:

  REGISTRATION_TOKEN - Get from Takaro Dashboard
  RCON_PASSWORD - Must match your AstroServerSettings.ini


Step 5: Start the Bridge
-------------------------
Double-click: start.bat

You should see:
  ✓ Connected to Takaro WebSocket
  ✓ Connected to Astroneer RCON


TROUBLESHOOTING
---------------

"node is not recognized"
  → Install Node.js and restart your computer

"RCON connection failed"
  → Check RCON_PASSWORD matches AstroServerSettings.ini
  → Make sure Astroneer server is running

"Cannot find module"
  → Run: npm install


USEFUL LINKS
------------
Documentation: https://mad-001.github.io/takaro-astroneer-bridge/
Report Issues: https://github.com/mad-001/takaro-astroneer-bridge/issues
Takaro Platform: https://takaro.io
